﻿using System;
using System.Collections;
using ProccessController;
using System.IO;
using System.Diagnostics;

namespace template_loader
{
    class Program
    {
        static (string,string) get_loader_code()
        {

            //Pass the file path and file name to the StreamReader constructor
            //StreamReader currentfile = new StreamReader("code.ylc");//System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName
            string fileCont= File.ReadAllText("code.ylc");

                //currentfile.Close();
        }
        static void Main(string[] args)
        {
            string code = get_loader_code();

            int pid = 41900;
            LoaderCommanderLoader commander = new LoaderCommanderLoader(pid);
            
            commander.Run(code);
            //ProccessController.ProccessController banana = new ProccessController.ProccessController(pid);
            //Byte[] b = (banana.read_memory(0x00000093076FF8A0, 9));//, new byte[] {0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x61 }
            //banana.write_memory(0x00000093076FF8A0,new byte[] { 0x61, 0x61, 0x61, 0x61, 0x61,0x0 });
            //var c = System.Text.Encoding.UTF8.GetString(b);
            //System.Console.WriteLine(c);

        }
    }
}