﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace template_loader
{
    class LoaderCommanderLoader: loaderCommander
    {
        ProccessController.ProccessController controlled;
        public LoaderCommanderLoader(int pid)
        {
            controlled = new ProccessController.ProccessController(pid);
        }
        public override ulong findCommand(byte[] what, ulong startAdress = 0)
        {
            throw new NotImplementedException();
        }

        protected override byte[] readMemory(ulong address, uint len)
        {
            return controlled.read_memory(address, len);
        }

        protected override void writeMemory(ulong address, byte[] data)
        {
            controlled.write_memory(address, data);
        }
    }
}
